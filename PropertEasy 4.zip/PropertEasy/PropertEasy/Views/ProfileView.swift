//
//  ProfileView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import SwiftUI
//
//struct ProfileView: View {
//    @EnvironmentObject var appVM: AppViewModel
//    @State private var isEditing = false
//    @State private var selectedServices: Set<String> = []
//    @State private var isProfessionalBinding: Bool = false  // Local state for toggle binding
//
//    private let availableServices = ["Property Valuation", "Legal Advice", "Inspection", "Marketing", "Financing"]
//
//    var body: some View {
//        NavigationView {
//            Form {
//                // Section 1: Basic User Info - Safe optional access
//                Section(header: Text("User  Information")) {
//                    Text("User  ID: /$appVM.profile?.userID ?? ",Not, loaded")")
//                        .font(.headline)
//                    Text("Joined: /$Date(), style: .date)")
//                        .foregroundColor(.secondary)
//                }
//
//                // Section 2: Professional Status - Fixed Binding
//                Section(header: Text("Professional Account")) {
//                    Toggle("Enable Professional Mode", isOn: Binding<Bool>(
//                        get: {
//                            isProfessionalBinding = appVM.profile?.isProfessional ?? false
//                            return isProfessionalBinding
//                        },
//                        set: { newValue in
//                            isProfessionalBinding = newValue
//                            // Update profile if loaded
//                            if var profile = appVM.profile {
//                                profile.isProfessional = newValue
//                                appVM.profile = profile  // Direct assign to @Published
//                            }
//                            if newValue && !selectedServices.isEmpty {
//                                if var profile = appVM.profile {
//                                    profile.services = Array(selectedServices)
//                                    appVM.profile = profile
//                                }
//                            }
//                        }
//                    ))
//                    .disabled(!isEditing)
//
//                    if appVM.profile?.isProfessional ?? false {
//                        Text("Services Offered:")
//                            .font(.subheadline)
//                        List(availableServices, id: \.self, selection: $selectedServices) { service in
//                            HStack {
//                                Text(service)
//                                Spacer()
//                                if selectedServices.contains(service) {
//                                    Image(systemName: "checkmark.circle.fill")
//                                        .foregroundColor(.green)
//                                }
//                            }
//                        }
//                        .onChange(of: selectedServices) { newServices in
//                            if var profile = appVM.profile {
//                                profile.services = Array(newServices)
//                                appVM.profile = profile
//                            }
//                        }
//                    } else {
//                        Text("Upgrade to professional for services like valuation and marketing.")
//                            .font(.caption)
//                            .foregroundColor(.secondary)
//                    }
//                }
//
//                // Section 3: Stats - Safe optionals
//                Section(header: Text("Earnings & Ratings")) {
//                    HStack {
//                        Text("Total Earnings: £/$appVM.profile?.earnings ?? 0, specifier: "%.2f")")
//                        Spacer()
//                        Text("Ratings: /$appVM.profile?.ratings ?? 0, specifier: "%.1f")/5")
//                    }
//                    .font(.subheadline)
//                }
//
//                // Section 4: Actions - Calls saveProfile (add to AppViewModel below)
//                Section {
//                    if isEditing {
//                        Button("Save Changes") {
//                            Task {
//                                if let profile = appVM.profile {
//                                    try? await appVM.saveProfile(profile)  // Now exists
//                                    isEditing = false
//                                }
//                            }
//                        }
//                        .foregroundColor(.white)
//                        .frame(maxWidth: .infinity)
//                        .background(Color.blue)
//                        .clipShape(RoundedRectangle(cornerRadius: 8))
//
//                        Button("Cancel") {
//                            isEditing = false
//                            Task { await appVM.loadProfile() }
//                        }
//                    } else {
//                        Button("Edit Profile") {
//                            isEditing = true
//                            selectedServices = Set(appVM.profile?.services ?? [])
//                            isProfessionalBinding = appVM.profile?.isProfessional ?? false
//                        }
//                        .frame(maxWidth: .infinity)
//                    }
//                }
//            }
//            .navigationTitle("My Profile")
//            .navigationBarTitleDisplayMode(.inline)
//            .toolbar {
//                ToolbarItem(placement: .navigationBarTrailing) {
//                    Button("Logout") {
//                        appVM.currentUserID = ""  // Fixed property name (no space)
//                    }
//                }
//            }
//            .onAppear {
//                if appVM.profile == nil {
//                    Task { await appVM.loadProfile() }
//                }
//                // Sync local binding
//                isProfessionalBinding = appVM.profile?.isProfessional ?? false
//                selectedServices = Set(appVM.profile?.services ?? [])
//            }
//        }
//    }
//}
//
//#Preview {
//    ProfileView()
//        .environmentObject(AppViewModel())
//}

//import SwiftUI
//
//struct ProfileView: View {
//    @EnvironmentObject var appVM: AppViewModel
//    @State private var isEditing = false
//    @State private var selectedServices: Set<String> = []
//    @State private var isProfessionalBinding: Bool = false
//
//    private let availableServices = [
//        "Property Valuation",
//        "Legal Advice",
//        "Inspection",
//        "Marketing",
//        "Financing"
//    ]
//
//    var body: some View {
//        NavigationView {
//            Form {
//                Section(header: Text("User Information")) {
//                    Text("User ID: \(appVM.profile?.userID ?? "Not loaded")")
//                        .font(.headline)
//                    if appVM.profile != nil {
//                        Text("Joined: \(Date(), style: .date)")
//                            .foregroundColor(.secondary)
//                    }
//                }
//
//                Section(header: Text("Professional Account")) {
//                    Toggle("Enable Professional Mode", isOn: $isProfessionalBinding)
//                }
//            }
//            .navigationTitle("Profile")
//        }
//    }
//}
//
//struct ProfileView_Previews: PreviewProvider {  // ✅ fixed
//    static var previews: some View {
//        ProfileView()
//            .environmentObject(AppViewModel())
//    }
//}

import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var appVM: AppViewModel

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("User Information")) {
                    Text("User ID: \(appVM.profile?.userID ?? "Not loaded")")
                    Text("Joined: \(Date(), style: .date)")
                }

                if let profile = appVM.profile {
                    Section(header: Text("Professional")) {
                        if profile.isProfessional {
                            Text("Services: \(profile.services.joined(separator: ", "))")
                        } else {
                            Text("Not a professional account")
                        }
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }
}
