//
//  ListingView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//
//
//import SwiftUI
//
//struct ListingView: View {
//    @EnvironmentObject var listingVM: ListingViewModel
//
//    var body: some View {
//        NavigationView {
//            List(listingVM.properties, id: \.id) { property in
//                VStack(alignment: .leading) {
//                    Text(property.title)
//                        .font(.headline)
//                    Text(property.location)
//                        .font(.subheadline)
//                }
//            }
//            .navigationTitle("Listings")
//        }
//    }
//}




import SwiftUI

struct ListingView: View {
    @EnvironmentObject var listingVM: ListingViewModel

    var body: some View {
        NavigationView {
            VStack {
                if listingVM.isLoading {
                    ProgressView("Loading properties...")
                } else if listingVM.filteredPropertyListings.isEmpty {
                    Text("No properties found")
                        .foregroundColor(.gray)
                } else {
                    List(listingVM.filteredPropertyListings, id: \.id) { property in
                        VStack(alignment: .leading) {
                            Text(property.title)
                                .font(.headline)
                            Text("$\(property.price, specifier: "%.2f") - \(property.location)")
                                .font(.subheadline).foregroundColor(.blue)
                            if !property.category.isEmpty {
                                Text("Category: \(property.category)")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }

                        }
                    }
                }

                // Search
                TextField("Search properties...", text: $listingVM.searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
            }
            //.navigationTitle("Properties")
            .onAppear {
                Task {
                    await listingVM.loadPropertyListings()
                }

            }
        }
    }
}





struct ListingView_Previews: PreviewProvider {
    static var previews: some View {
        ListingView()
            .environmentObject(ListingViewModel())
    }
}



