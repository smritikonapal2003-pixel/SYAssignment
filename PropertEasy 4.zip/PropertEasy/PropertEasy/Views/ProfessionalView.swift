//
//  ProfessionalView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import SwiftUI

struct ProfessionalView: View {
    var body: some View {
        NavigationView {
            Text("Professional Screen")
                .navigationTitle("Professional")
        }
    }
}

struct ProfessionalView_Previews: PreviewProvider {
    static var previews: some View {
        ProfessionalView()
    }
}
