//
//  MessagingView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import SwiftUI

struct MessagingView: View {
    @EnvironmentObject var messagingVM: MessagingViewModel

    var body: some View {
        NavigationView {
            List(messagingVM.messages, id: \.id) { msg in
                VStack(alignment: .leading) {
                    Text(msg.senderID)
                        .font(.caption)
                        .foregroundColor(.gray)
                    Text(msg.content)
                }
            }
            .navigationTitle("Messages")
        }
    }
}



