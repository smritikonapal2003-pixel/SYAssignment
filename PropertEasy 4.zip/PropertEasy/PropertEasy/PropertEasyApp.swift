//
//  PropertEasyApp.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import SwiftUI
//
//@main
//struct PropertEasyApp: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
import SwiftUI

@main
struct PropertEasyApp: App {
    
    @StateObject var appVM = AppViewModel()
    @StateObject var listingVM = ListingViewModel()
    @StateObject var messagingVM = MessagingViewModel()
    @StateObject var professionalVM = ProfessionalViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appVM)
                .environmentObject(listingVM)
                .environmentObject(messagingVM)
                .environmentObject(professionalVM)
                
        }
    }
}
