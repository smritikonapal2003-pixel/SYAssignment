//
//  PropertyListing.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//
//  PropertyListing.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import Foundation
import CloudKit

struct PropertyListing: Identifiable {
    let id: UUID = UUID()
    let title: String
    let price: Double
    let location: String
    let category: String
    let images: [String]
    let ownerID: String
    let bedrooms: Double
    let bathrooms: Double

    // Default init (empty)
    init() {
        title = ""
        price = 0.0
        location = ""
        category = ""
        images = []
        ownerID = ""
        bedrooms = 0.0
        bathrooms = 0.0
    }

    // Convenience init for ViewModel/forms
    init(title: String, price: Double, location: String, category: String = "", images: [String] = [], ownerID: String = "", bedrooms: Double, bathrooms: Double) {
        self.title = title
        self.price = price
        self.location = location
        self.category = category
        self.images = images
        self.ownerID = ownerID
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
    }

    // CloudKit init
    init(from record: CKRecord) {
        title = record["title"] as? String ?? ""
        price = record["price"] as? Double ?? 0.0
        location = record["location"] as? String ?? ""
        category = record["category"] as? String ?? ""
        images = record["images"] as? [String] ?? []
        ownerID = record["ownerID"] as? String ?? ""
        bedrooms = record["bedrooms"] as? Double ?? 0.0
        bathrooms = record["bathrooms"] as? Double ?? 0.0
        
    }

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "PropertyListing")
        record["title"] = title
        record["price"] = price
        record["location"] = location
        record["category"] = category
        record["images"] = images
        record["ownerID"] = ownerID
        record["bedrooms"] = bedrooms
        record["bathrooms"] = bathrooms
        return record
    }
}
