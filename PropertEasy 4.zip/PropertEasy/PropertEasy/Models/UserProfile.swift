//
//  UserProfile.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import Foundation
//import CloudKit
//
//class UserProfile: Identifiable {
//    var id: UUID = UUID()
//    var userID: String = ""  // Unique identifier
//    var isProfessional: Bool = false
//    var earnings: Double = 0.0
//    var ratings: Double = 0.0
//    var services: [String] = []  // e.g., ["Estate Agent"]
//
//    init() {}
//
//    func toCKRecord() -> CKRecord {
//        let record = CKRecord(recordType: "User  Profile")  // Matches schema; adjust if no space
//        record["userID"] = userID
//        record["isProfessional"] = isProfessional
//        record["earnings"] = earnings
//        record["ratings"] = ratings
//        record["services"] = services
//        return record
//    }
//
//    init(from record: CKRecord) {
//        id = UUID()
//        userID = record["userID"] as? String ?? ""
//        isProfessional = record["isProfessional"] as? Bool ?? false
//        earnings = record["earnings"] as? Double ?? 0.0
//        ratings = record["ratings"] as? Double ?? 0.0
//        services = record["services"] as? [String] ?? []
//    }
//}




import Foundation
import CloudKit

struct UserProfile: Identifiable {
    let id: UUID = UUID()
    var userID: String = "" // Unique identifier
    var isProfessional: Bool = false
    var earnings: Double = 0.0
    var ratings: Double = 0.0
    var services: [String] = []
    // Default init (empty)
    init() {}

    // Convenience init for AppViewModel/UI
    init(userID: String, isProfessional: Bool = false, earnings: Double = 0.0, ratings: Double = 0.0, services: [String] = []) {
        self.userID = userID
        self.isProfessional = isProfessional
        self.earnings = earnings
        self.ratings = ratings
        self.services = services
    }

     //CloudKit init
//    init(from record: CKRecord) {
//        userID = record["userID"] as? String ?? ""
//        isProfessional = record["isProfessional"] as? Bool ?? false
//        earnings = record["earnings"] as? Double ?? 0.0
//        ratings = record["ratings"] as? Double ?? 0.0
//        services = record["services"] as? [String] ?? []
//    }
    init?(from record: CKRecord) {
        guard let userID = record["userID"] as? String else { return nil }
        self.userID = userID
        self.isProfessional = record["isProfessional"] as? Bool ?? false
        self.services = record["services"] as? [String] ?? []
        self.earnings = record["earnings"] as? Double ?? 0.0
        self.ratings = record["ratings"] as? Double ?? 0.0

    }
    

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "User Profile")  // Fixed: Clean name
        record["userID"] = userID as CKRecordValue?
        record["isProfessional"] = isProfessional as CKRecordValue?
        record["earnings"] = earnings as CKRecordValue?
        record["ratings"] = ratings as CKRecordValue?
        record["services"] = services as CKRecordValue?
        return record
    }
}
