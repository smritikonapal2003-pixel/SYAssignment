//
//  Message.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import Foundation
//import CloudKit
//
//class Message: Identifiable {
//    var id: UUID = UUID()
//    var senderID: String = ""
//    var receiverID: String = ""
//    var content: String = ""
//    var timestamp: Date = Date()
//    var isAudio: Bool = false
//
//    init() {}
//
//    init(content: String, senderID: String, receiverID: String, timestamp: Date = Date(), isAudio: Bool = false) {
//        self.content = content
//        self.senderID = senderID
//        self.receiverID = receiverID
//        self.timestamp = timestamp
//        self.isAudio = isAudio
//    }
//
//    func toCKRecord() -> CKRecord {
//        let record = CKRecord(recordType: "Message")
//        record["senderID"] = senderID
//        record["receiverID"] = receiverID
//        record["content"] = content
//        record["timestamp"] = timestamp
//        record["isAudio"] = isAudio
//        return record
//    }
//
//    init(from record: CKRecord) {
//        id = UUID()
//        senderID = record["senderID"] as? String ?? ""
//        receiverID = record["receiverID"] as? String ?? ""
//        content = record["content"] as? String ?? ""
//        timestamp = record["timestamp"] as? Date ?? Date()
//        isAudio = record["isAudio"] as? Bool ?? false
//    }
//}




import Foundation
import CloudKit

struct Message: Identifiable {
    let id: UUID = UUID()
    let senderID: String
    let receiverID: String
    let content: String
    let timestamp: Date
    let isAudio: Bool
    ////let messageID: String
    

    // Default init (empty)
    init() {
        self.senderID = ""
        self.receiverID = ""
        self.content = ""
        self.timestamp = Date()
        self.isAudio = false
       // self.messageID = ""
    }

    // Convenience init for ViewModel
    // Fixed: Convenience init with defaults - Allows Message(content: "text") if needed
    init(content: String, senderID: String = "testuser", receiverID: String = "otheruser", timestamp: Date = Date(), isAudio: Bool = false, messageID: String) {
        self.content = content
        self.senderID = senderID
        self.receiverID = receiverID
        self.timestamp = timestamp
        self.isAudio = isAudio
        //self.messageID = messageID
    }

    // CloudKit init
    init(from record: CKRecord) {
        senderID = record["senderID"] as? String ?? ""
        receiverID = record["receiverID"] as? String ?? ""
        content = record["content"] as? String ?? ""
        timestamp = record["timestamp"] as? Date ?? Date()
        isAudio = record["isAudio"] as? Bool ?? false
       // messageID = record["messageID"] as? String ?? ""
    }

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "Message")
        record["senderID"] = senderID
        record["receiverID"] = receiverID
        record["content"] = content
        record["timestamp"] = timestamp
        record["isAudio"] = isAudio
       // record["messageID"] = messageID
        return record
    }
}
