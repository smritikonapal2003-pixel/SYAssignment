//
//  Promotion.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import Foundation
//import CloudKit
//
//class Promotion: Identifiable {
//    var id: UUID = UUID()
//    var listingID: String = ""
//    var boostLevel: Int = 0  // e.g., 1-5 for visibility
//    var verified: Bool = false
//
//    init() {}
//
//    func toCKRecord() -> CKRecord {
//        let record = CKRecord(recordType: "Promotion")
//        record["listingID"] = listingID
//        record["boostLevel"] = boostLevel
//        record["verified"] = verified
//        return record
//    }
//
//    init(from record: CKRecord) {
//        id = UUID()
//        listingID = record["listingID"] as? String ?? ""
//        boostLevel = record["boostLevel"] as? Int ?? 0
//        verified = record["verified"] as? Bool ?? false
//    }
//}



import Foundation
import CloudKit

struct Promotion: Identifiable {
    let id: UUID = UUID()
    let listingID: String
    let boostLevel: Int  // e.g., 1-5 for visibility
    let verified: Bool

    // Default init (empty)
    init() {
        listingID = ""
        boostLevel = 0
        verified = false
    }

    // Convenience init for ViewModel/UI
    init(listingID: String, boostLevel: Int = 0, verified: Bool = false) {
        self.listingID = listingID
        self.boostLevel = boostLevel
        self.verified = verified
    }

    // CloudKit init
    init(from record: CKRecord) {
        listingID = record["listingID"] as? String ?? ""
        boostLevel = record["boostLevel"] as? Int ?? 0
        verified = record["verified"] as? Bool ?? false
    }

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "Promotion")
        record["listingID"] = listingID
        record["boostLevel"] = boostLevel
        record["verified"] = verified
        return record
    }
}
