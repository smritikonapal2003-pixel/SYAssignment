
//    func fetchProfile(for userID: String) async throws -> UserProfile? {
//        let predicate = NSPredicate(format: "userID == %@", userID)
//        let query = CKQuery(recordType: "UserProfile", predicate: predicate)
//        let (results, _) = try await privateDB.records(matching: query)
//
//        return results.compactMap { (_, result) in
//            switch result {
//            case .success(let record):
//                return UserProfile(from: record)
//            case .failure:
//                return nil
//            }
//        }.first
//    }
//
//    // Messages
//
//        func saveMessage(_ message: Message) async throws {
//            let record = message.toCKRecord()
//            try await publicDB.save(record)
//            print("CloudKit: Saved Message")
//        }
//
//        func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
//            let predicate = NSPredicate(format: "(senderID == %@ AND receiverID == %@) OR (senderID == %@ AND receiverID == %@)",
//                                        senderID, receiverID, receiverID, senderID)
//            let query = CKQuery(recordType: "PropertyListing", predicate: predicate)
//
//            let (results, _) = try await publicDB.records(matching: query)
//            return results.compactMap { (_, result) in
//                switch result {
//                case .success(let record):
//                    return Message(from: record)
//                case .failure:
//                    return nil
//                }
//            }.sorted { $0.timestamp < $1.timestamp }
//        }
//
////        func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
////            // Query 1: Messages sent by senderID to receiverID
////            let sentPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", senderID, receiverID)
////            let sentQuery = CKQuery(recordType: "Message", predicate: sentPredicate)
////
////            // Query 2: Messages sent by receiverID to senderID (received)
////            let receivedPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", receiverID, senderID)
////            let receivedQuery = CKQuery(recordType: "Message", predicate: receivedPredicate)
////
////            // Execute both queries
////            let (sentResults, _) = try await publicDB.records(matching: sentQuery)
////            let (receivedResults, _) = try await publicDB.records(matching: receivedQuery)
////
////            // Combine and map to Message (handle success/failure)
////            var allMessages: [Message] = []
////            allMessages.append(contentsOf: sentResults.compactMap { try? Message(from: $0.1.record!) })
////            allMessages.append(contentsOf: receivedResults.compactMap { try? Message(from: $0.1.record!) })
////
////            // Sort by timestamp (ascending)
////            return allMessages.sorted { $0.timestamp < $1.timestamp }
////        }
//
////    // MARK: - Messages (Public DB)
////
////    func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
////        print("DEBUG: Fetching messages between \(senderID) and \(receiverID) from Public DB")
////        let predicate = NSPredicate(format: "(senderID == %@ AND receiverID == %@) OR (senderID == %@ AND receiverID == %@)",
////                                    senderID, receiverID, receiverID, senderID)
////        let query = CKQuery(recordType: "Message", predicate: predicate)
////
////        let (resultDict, _) = try await publicDB.records(matching: query)
////        print("DEBUG: Raw message resultDict count: \(resultDict.count)")
////
////        // Extract valid CKRecords (Fixes second conversion error)
////        let records = resultDict.compactMap { (_, result) -> CKRecord? in
////            if case .success(let record) = result {
////                return record
////            } else if case .failure(let error) = result {
////                print("DEBUG: Skipped failed message record: \(error.localizedDescription)")
////                return nil
////            }
////            return nil
////        }
////        print("DEBUG: Valid message records extracted: \(records.count)")
////        let messages = records.compactMap { record -> Message? in
////            print("DEBUG: Parsing message: \(record.recordID.recordName ) - Content: \(record["content"] ?? "nil")")
////            return Message(from: record)
////        }
////        print("DEBUG: Parsed messages: \(messages.count)")
////        return messages.sorted { $0.timestamp < $1.timestamp }  // Chronological
////    }
////
////    func saveMessage(_ message: Message) async throws {
////        let record = CKRecord(recordType: "Message")
////        record["messageID"] = message.messageID
////        record["senderID"] = message.senderID
////        record["receiverID"] = message.receiverID
////        record["content"] = message.content
////        record["timestamp"] = message.timestamp
////        try await publicDB.save(record)
////        print("DEBUG: Message saved: \(message.content)")
////    }
//
////    func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
////        print("Fetching messages between \(senderID) and \(receiverID)")
////
////        // Query 1: Sent
////        let sentPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", senderID, receiverID)
////        let sentQuery = CKQuery(recordType: "Message", predicate: sentPredicate)
////        let (sentResults, _) = try await publicDB.records(matching: sentQuery)
////
////        // Query 2: Received
////        let receivedPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", receiverID, senderID)
////        let receivedQuery = CKQuery(recordType: "Message", predicate: receivedPredicate)
////        let (receivedResults, _) = try await publicDB.records(matching: receivedQuery)
////
////        // Fixed: Handle Result in both - Combine successes
////        var allMessages: [Message] = []
////        allMessages.append(contentsOf: sentResults.compactMap { (_, result) in
////            if case .success(let record) = result {
////                return try? Message(from: record)
////            }
////            return nil
////        })
////        allMessages.append(contentsOf: receivedResults.compactMap { (_, result) in
////            if case .success(let record) = result {
////                return try? Message(from: record)
////            }
////            return nil
////        })
////
////        let sortedMessages = allMessages.sorted { $0.timestamp < $1.timestamp }
////        print("Fetched \(sortedMessages.count) messages")
////        return sortedMessages
////    }
////
////    func saveMessage(_ message: Message) async throws {
////        let record = message.toCKRecord()
////        try await publicDB.save(record)
////        print("CloudKit: Saved Message")
////    }
//
//    // Promotions (Private)
//    func savePromotion(_ promotion: Promotion) async throws {
//        let record = promotion.toCKRecord()
//        try await privateDB.save(record)
//        print("CloudKit: Saved Promotion")
//    }
//
//    func fetchPromotions() async throws -> [Promotion] {
//        let query = CKQuery(recordType: "Promotion", predicate: NSPredicate(value: true))
//        let (results, _) = try await privateDB.records(matching: query)
//
//        return results.compactMap { (_, result) in
//            switch result {
//            case .success(let record):
//                return Promotion(from: record)
//            case .failure:
//                return nil
//            }
//        }
//    }
//}
//
//    // Shared instance
//let sharedCloudKitService = CloudKitService()
//


import Foundation
import CloudKit

class CloudKitService: ObservableObject {
    private let publicDB = CKContainer.default().publicCloudDatabase
    private let privateDB = CKContainer.default().privateCloudDatabase
    
    // PropertyListing
    func savePropertyListing(_ listing: PropertyListing) async throws {
        let record = listing.toCKRecord()
        try await publicDB.save(record)
        print("CloudKit: Saved PropertyListing")
    }
    //
    func fetchProperties(filter: String? = nil) async throws -> [PropertyListing] {
        let predicate = filter?.isEmpty == false
        ? NSPredicate(format: "location CONTAINS[c] %@", filter!)
        : NSPredicate(value: true)
        
        let query = CKQuery(recordType: "PropertyListing", predicate: predicate)
        let (results, _) = try await publicDB.records(matching: query)
        
        return results.compactMap { (_, result) in
            switch result {
            case .success(let record):
                return PropertyListing(from: record)
            case .failure:
                return nil
            }
        }
    }
    
    //UserProfile (Private)
    func saveProfile(_ profile: UserProfile) async throws {
        let record = profile.toCKRecord()
        _ = try await privateDB.save(record)
    }
    
    func fetchProfile(for userID: String) async throws -> UserProfile? {
        let predicate = NSPredicate(format: "userID == %@", userID)
        let query = CKQuery(recordType: "UserProfile", predicate: predicate) // ✅ record type without space
        let (results, _) = try await privateDB.records(matching: query)
        
        return results.compactMap { (_, result) in
            switch result {
            case .success(let record):
                return UserProfile(from: record)
            case .failure:
                return nil
            }
        }.first
    }
    
    // Messages
    
//    func saveMessage(_ message: Message) async throws {
//        let record = message.toCKRecord()
//        try await publicDB.save(record)
//        print("CloudKit: Saved Message")
//    }
    
//    func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
//        let predicate = NSPredicate(format: "(senderID == %@ AND receiverID == %@) OR (senderID == %@ AND receiverID == %@)",
//                                    senderID, receiverID, receiverID, senderID)
//        let query = CKQuery(recordType: "PropertyListing", predicate: predicate)
//
//        let (results, _) = try await publicDB.records(matching: query)
//        return results.compactMap { (_, result) in
//            switch result {
//            case .success(let record):
//                return Message(from: record)
//            case .failure:
//                return nil
//            }
//        }.sorted { $0.timestamp < $1.timestamp }
//    }
    
//    func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
//        // Query 1: Messages sent by senderID to receiverID
//        let sentPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", senderID, receiverID)
//        let sentQuery = CKQuery(recordType: "Message", predicate: sentPredicate)
//
//        // Query 2: Messages sent by receiverID to senderID (received)
//        let receivedPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", receiverID, senderID)
//        let receivedQuery = CKQuery(recordType: "Message", predicate: receivedPredicate)
//
//        // Execute both queries
//        let (sentResults, _) = try await publicDB.records(matching: sentQuery)
//        let (receivedResults, _) = try await publicDB.records(matching: receivedQuery)
//
//        // Combine and map to Message (handle success/failure)
//        var allMessages: [Message] = []
//        allMessages.append(contentsOf: sentResults.compactMap { try? Message(from: $0.1.record!) })
//        allMessages.append(contentsOf: receivedResults.compactMap { try? Message(from: $0.1.record!) })
//
//        // Sort by timestamp (ascending)
//        return allMessages.sorted { $0.timestamp < $1.timestamp }
//    }
    
    // MARK: - Messages (Public DB)
    func fetchMessages(senderID: String, receiverID: String) async throws -> [Message] {
        print("Fetching messages between \(senderID) and \(receiverID)")
        
        // Query 1: Sent
        let sentPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", senderID, receiverID)
        let sentQuery = CKQuery(recordType: "Message", predicate: sentPredicate)
        let (sentResults, _) = try await publicDB.records(matching: sentQuery)
        
        // Query 2: Received
        let receivedPredicate = NSPredicate(format: "senderID == %@ AND receiverID == %@", receiverID, senderID)
        let receivedQuery = CKQuery(recordType: "Message", predicate: receivedPredicate)
        let (receivedResults, _) = try await publicDB.records(matching: receivedQuery)
        
        // Fixed: Handle Result in both - Combine successes
        var allMessages: [Message] = []
        allMessages.append(contentsOf: sentResults.compactMap { (_, result) in
            if case .success(let record) = result {
                return try? Message(from: record)
            }
            return nil
        })
        allMessages.append(contentsOf: receivedResults.compactMap { (_, result) in
            if case .success(let record) = result {
                return try? Message(from: record)
            }
            return nil
        })
        
        let sortedMessages = allMessages.sorted { $0.timestamp < $1.timestamp }
        print("Fetched \(sortedMessages.count) messages")
        return sortedMessages
    }

    func saveMessage(_ message: Message) async throws {
        let record = message.toCKRecord()
        try await publicDB.save(record)
        print("CloudKit: Saved Message")
    }
    
    // Promotions (Private)
    func savePromotion(_ promotion: Promotion) async throws {
        let record = promotion.toCKRecord()
        try await privateDB.save(record)
        print("CloudKit: Saved Promotion")
    }
    
    func fetchPromotions() async throws -> [Promotion] {
        let query = CKQuery(recordType: "Promotion", predicate: NSPredicate(value: true))
        let (results, _) = try await privateDB.records(matching: query)
        
        return results.compactMap { (_, result) in
            switch result {
            case .success(let record):
                return Promotion(from: record)
            case .failure:
                return nil
            }
        }
    }
}

    // Shared instance
let sharedCloudKitService = CloudKitService()
