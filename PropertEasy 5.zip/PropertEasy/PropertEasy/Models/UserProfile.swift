
import Foundation
import CloudKit

struct UserProfile: Identifiable {
    let id: UUID = UUID()
    var userID: String = "" // Unique identifier
    var isProfessional: Bool = false
    var earnings: Double = 0.0
    var ratings: Double = 0.0
    var services: [String] = []
    // Default init (empty)
    init() {}

    // Convenience init for AppViewModel/UI
    init(userID: String, isProfessional: Bool = false, earnings: Double = 0.0, ratings: Double = 0.0, services: [String] = []) {
        self.userID = userID
        self.isProfessional = isProfessional
        self.earnings = earnings
        self.ratings = ratings
        self.services = services
    }

    init?(from record: CKRecord) {
        guard let userID = record["userID"] as? String else { return nil }
        self.userID = userID
        self.isProfessional = record["isProfessional"] as? Bool ?? false
        self.services = record["services"] as? [String] ?? []
        self.earnings = record["earnings"] as? Double ?? 0.0
        self.ratings = record["ratings"] as? Double ?? 0.0

    }
    

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "User Profile")  // Fixed: Clean name
        record["userID"] = userID as CKRecordValue?
        record["isProfessional"] = isProfessional as CKRecordValue?
        record["earnings"] = earnings as CKRecordValue?
        record["ratings"] = ratings as CKRecordValue?
        record["services"] = services as CKRecordValue?
        return record
    }
}
