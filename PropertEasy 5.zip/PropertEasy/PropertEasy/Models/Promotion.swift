
import Foundation
import CloudKit

struct Promotion: Identifiable {
    let id: UUID = UUID()
    let listingID: String
    let boostLevel: Int  
    let verified: Bool

    // Default init (empty)
    init() {
        listingID = ""
        boostLevel = 0
        verified = false
    }

    // Convenience init for ViewModel/UI
    init(listingID: String, boostLevel: Int = 0, verified: Bool = false) {
        self.listingID = listingID
        self.boostLevel = boostLevel
        self.verified = verified
    }

    // CloudKit init
    init(from record: CKRecord) {
        listingID = record["listingID"] as? String ?? ""
        boostLevel = record["boostLevel"] as? Int ?? 0
        verified = record["verified"] as? Bool ?? false
    }

    func toCKRecord() -> CKRecord {
        let record = CKRecord(recordType: "Promotion")
        record["listingID"] = listingID
        record["boostLevel"] = boostLevel
        record["verified"] = verified
        return record
    }
}
