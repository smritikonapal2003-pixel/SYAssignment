
import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var appVM: AppViewModel

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("User Information")) {
                    Text("User ID: \(appVM.profile?.userID ?? "Not loaded")")
                    Text("Joined: \(Date(), style: .date)")
                }

                if let profile = appVM.profile {
                    Section(header: Text("Professional")) {
                        if profile.isProfessional {
                            Text("Services: \(profile.services.joined(separator: ", "))")
                        } else {
                            Text("Not a professional account")
                        }
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }
}
