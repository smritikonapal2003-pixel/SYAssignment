//
//  ContentView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

//import SwiftUI
//
//struct ContentView: View {
//    var body: some View {
//        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundColor(.accentColor)
//            Text("Hello, world!")
//        }
//        .padding()
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appVM: AppViewModel
    @EnvironmentObject var listingVM: ListingViewModel
    @EnvironmentObject var messagingVM: MessagingViewModel
    @EnvironmentObject var professionalVM: ProfessionalViewModel

    var body: some View {
        TabView {
            ListingView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Listings")
                }
                .environmentObject(appVM)
                .environmentObject(listingVM)

            MessagingView()
                .tabItem {
                    Image(systemName: "message.fill")
                    Text("Messages")
                }
                .environmentObject(appVM)
                .environmentObject(messagingVM)

            ProfessionalView()
                .tabItem {
                    Image(systemName: "person.2.fill")
                    Text("Professional")
                }
                .environmentObject(appVM)
                .environmentObject(professionalVM)

            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
                .environmentObject(appVM)
        }
        .accentColor(.blue)
        .onAppear {
            Task {
                await appVM.loadProfile()
                await listingVM.loadPropertyListings()
                await messagingVM.loadMessages()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AppViewModel())
            .environmentObject(ListingViewModel())
            .environmentObject(MessagingViewModel())
            .environmentObject(ProfessionalViewModel())
    }
}
