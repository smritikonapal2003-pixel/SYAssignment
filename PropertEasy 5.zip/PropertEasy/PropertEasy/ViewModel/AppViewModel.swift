
//
//  AppViewModel.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import SwiftUI
import CloudKit  // For CKContainer.accountStatus

@MainActor
class AppViewModel: ObservableObject {
    @Published var profile: UserProfile?
    @Published var currentUserID: String = "testuser"
    let service = CloudKitService()
    
    init() {
        Task { await loadProfile() }
    }
    
    func loadProfile() async {
        do {
            // Debug: Print status before check
            print("Checking iCloud status...")
            let container = CKContainer.default()
            let status: CKAccountStatus = try await container.accountStatus()
            print("iCloud Status: \(status)")  // Debug: Confirms .available, .noAccount, etc.
            
            if status != .available {
                print("iCloud not available: \(status) - Sign in required")
                profile = nil
                return
            }
            
            print("iCloud available - Fetching profile for \(currentUserID)")
            profile = try await service.fetchProfile(for: currentUserID)
            
            if profile == nil {
                print("No profile found - Creating new one")
                profile = UserProfile(userID: currentUserID, isProfessional: false, services: [])
                if let newProfile = profile {
                    try? await saveProfile(newProfile)
                    print("Created and saved new profile")
                }
            } else {
                print("Profile loaded successfully")
            }
        } catch {
            print("Catch block hit - Error: \(error.localizedDescription)")
            if let nsError = error as NSError?, nsError.code == 1002 {
                print("Specific: iCloud authentication required (Code 1002) - Sign in to continue")
            } else {
                print("Other error: \(error.localizedDescription)")
            }
            profile = nil
        }
    }
    
    func saveProfile(_ profile: UserProfile) async throws {
        try await service.saveProfile(profile)
    }
    
    func updateToProfessional(services: [String]) {
        profile?.isProfessional = true
        profile?.services = services
        
        Task {
            if let profile = profile {
                do {
                    try await saveProfile(profile)
                    print("Updated and saved professional profile: \(services)")
                } catch {
                    print("Error saving professional profile: \(error.localizedDescription)")
                }
            }
        }
    }
}
