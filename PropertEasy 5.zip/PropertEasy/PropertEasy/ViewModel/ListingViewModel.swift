//
//  ListingViewModel.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import Foundation
import SwiftUI
import CloudKit

@MainActor
class ListingViewModel: ObservableObject {
    @Published var properties: [PropertyListing] = []
    @Published var promotions: [Promotion] = []
    @Published var searchText: String = ""
    @Published var isLoading: Bool = false
    //@Published var errorMessage: String? = nil
    
    
    private let service = sharedCloudKitService
    
    
    func loadPropertyListings() async {
//        print("Loading mock properties (iCloud bypassed)")
//        properties = [
//            PropertyListing(
//                title: "prop001",
//                price: 500000, location: "Central London",
//                category: "Modern apartment with great views", images: ["https://example.com/london1.jpg", "https://example.com/london2.jpg"], bedrooms: 3,
//                bathrooms: 2
//            ),
//
//            PropertyListing(
//                title: "prop002",
//                price: 300000, location: "Manchester City Centre",
//                category: "Cozy flat near amenities", images: ["https://example.com/manchester.jpg"], bedrooms: 2,
//                bathrooms: 1
//            ),
//            PropertyListing(
//                title: "prop003",
//                price: 400000, location: "Birmingham Outskirts",
//                category: "Family home with garden", images: ["https://example.com/birmingham.jpg"], bedrooms: 4,
//                bathrooms: 3
//            )
//        ]
//        print("Mock properties loaded: \(properties.count) items")
//
//        // Apply filter if any (for search test)
//        if !searchText.isEmpty {
//            properties = properties.filter { $0.location.localizedCaseInsensitiveContains(searchText) }
//        }
//    }
//    func updateFilter(_ filter: String) {
//        searchText = filter
//        Task { await loadPropertyListings() }  // Reload with filter
//    }
//}
        isLoading = true
        defer { isLoading = false }
        do {
            properties = try await service.fetchProperties()
            promotions = try await service.fetchPromotions()
            print("Loaded \(properties.count) property listings and \(promotions.count) promotions")
        } catch {
            print("Error loading property listings: \(error.localizedDescription)")
            properties = []
            promotions = []
        }
    }

    func addPropertyListing(_ listing: PropertyListing) async {
        do {
            try await service.savePropertyListing(listing)
            await loadPropertyListings()
            print("Property listing added successfully")
        } catch {
            print("Error adding property listing: \(error.localizedDescription)")
        }
    }

    func addPromotion(_ promotion: Promotion) async {
        do {
            try await service.savePromotion(promotion)
            await loadPropertyListings()
            print("Promotion listing added successfully")
        } catch {
            print("Error adding promotion: \(error.localizedDescription)")
        }
    }

    var filteredPropertyListings: [PropertyListing] {
        if searchText.isEmpty {
            return properties
        } else {
            return properties.filter { $0.title.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
}
