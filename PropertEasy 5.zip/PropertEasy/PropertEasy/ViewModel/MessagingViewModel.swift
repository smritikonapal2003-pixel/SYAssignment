
import Foundation
import SwiftUI
import CloudKit

@MainActor
class MessagingViewModel: ObservableObject {
    @Published var messages: [Message] = []
    @Published var newMessageText: String = ""
    let service = CloudKitService()
    
    func loadMessages(for receiverID: String = "otheruser") async {
        do {
            messages = try await service.fetchMessages(senderID: "testuser", receiverID: receiverID)
            messages.sort { $0.timestamp < $1.timestamp }
            print("Loaded \(messages.count) messages")  // Fixed: Clean print (no "/$")
        } catch {
            print("Error loading messages: \(error.localizedDescription)")  // Fixed: Clean error print
            messages = []
        }
    }
    func sendMessage() async {
        guard !newMessageText.isEmpty else { return }
        
        // Create with full params (matches Message.swift init) - No partial call error
        let message = Message(
            content: newMessageText,
            senderID: "testuser",  // Hardcoded for MVP (integrate appVM.currentUser  later)
            receiverID: "otheruser", messageID: UUID().uuidString
        )
        
        do {
            try await service.saveMessage(message)
            newMessageText = ""
            await loadMessages()  // Uses default receiverID - No missing 'for:'
            print("Message sent successfully")
        } catch {
            print("Error sending message: \(error.localizedDescription)")
        }
    }
}

