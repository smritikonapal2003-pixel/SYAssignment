//
//  ProfessionalViewModel.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 02/10/25.
//

import Foundation
import SwiftUI

@MainActor
class ProfessionalViewModel: ObservableObject {
    @Published var selectedServices: Set<String> = []
    let availableServices = ["Estate Agent", "Letting Agent", "Valuation Expert"]
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    private let service = sharedCloudKitService

    func registerAsProfessional(appVM: AppViewModel) {
        _ = Array(selectedServices)
        //appVM.updateToProfessional(services: servicesArray)
        print("Registered as professional with services: /(servicesArray)")
    }

    func boostListing(listingID: String) async {
        isLoading = true
        errorMessage = nil
        
        let promotion = Promotion(
            listingID: listingID,
            boostLevel: 3,
            verified: true
        )
        
        do {
            try await service.savePromotion(promotion)
            print("Boosted listing: /$listingID)")
        } catch {
            errorMessage = "Boost failed: /$error.localizedDescription)"
            print("Boost error: /$error)")
        }
        isLoading = false
    }
}
